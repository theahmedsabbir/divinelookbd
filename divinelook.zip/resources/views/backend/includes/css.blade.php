
<link href="{{ asset('backend/lib/@fortawesome/fontawesome-free/css/all.min.css') }}" rel="stylesheet">
<link href="{{ asset('backend/lib/ionicons/css/ionicons.min.css') }}" rel="stylesheet">
{{-- <link href="{{ asset('backend/lib/rickshaw/rickshaw.min.css') }}" rel="stylesheet"> --}}
<link href="{{ asset('backend/lib/select2/css/select2.min.css') }}" rel="stylesheet">
{{-- <link rel="stylesheet" href="{{ asset('backend/css/jquery.dataTables.min.css') }}"> --}}
<link rel="stylesheet" href="{{ asset('backend/css/jquery.dataTables.min.css') }}">

  <link rel="stylesheet" href="{{ asset('backend/css/buttons.dataTables.min.css') }}">  
{{-- <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css"> --}}
{{-- <link href="{{ asset('backend/lib/datatables.net-dt/css/jquery.dataTables.min.css') }}" rel="stylesheet"> --}}
{{-- <link href="{{ asset('backend/lib/datatables.net-responsive-dt/css/responsive.dataTables.min.css') }}" rel="stylesheet"> --}}
<link href="{{ asset('backend/lib/medium-editor/css/medium-editor.min.css') }}" rel="stylesheet">
<link href="{{ asset('backend/lib/medium-editor/css/themes/default.min.css') }}" rel="stylesheet">
<link href="{{ asset('backend/lib/summernote/summernote-bs4.css') }}" rel="stylesheet">

<link href="{{ asset('backend/css/toastr.min.css') }}" rel="stylesheet">



<!-- Bracket CSS -->
<link rel="stylesheet" href="{{ asset('backend/css/bracket.css') }}">

<style>
	.dataTables_wrapper{
		width: 99% !important;
	}
	#datatable3 th{
		padding-right: 30px;
	}
	label,th,option{
		text-transform: capitalize;
	}
</style>
