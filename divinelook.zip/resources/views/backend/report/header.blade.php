<div class="br-pagetitle">
	<i class="icon ion-stats-bars"></i>
	<div>
	  <h4>{{ $page }} Report</h4>
	  <p class="mg-b-0">
	  	<a href="{{ url('admin/dashboard') }}">Dashboard</a> 
	  	/ Report / 
		{{ $page }}
	  </p>
	</div>
</div>