@extends('frontend.master')

@push('style')

@endpush


@section('content')
	
@endsection



@push('script')

@endpush