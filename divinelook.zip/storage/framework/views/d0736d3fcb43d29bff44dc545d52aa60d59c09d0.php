

<?php $__env->startSection('content'); ?>
    <!-- ======================= Main Content ======================== -->
    <div class="main-content main-content-details single no-sidebar">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcrumb-trail breadcrumbs">
                        <ul class="trail-items breadcrumb">
                            <li class="trail-item trail-begin">
                                <a href="<?php echo e(url('/')); ?>">Home</a>
                            </li>

                            <li class="trail-item trail-end active">
                                Product Details
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="content-area content-details full-width col-lg-9 col-md-8 col-sm-12 col-xs-12">
                    <div class="site-main">
                        <div class="details-product">
                            <div class="details-thumd">
                                <div class="image-preview-container image-thick-box image_preview_container">
                                    <img id="img_zoom" data-zoom-image="<?php echo e(asset('/product/'.$product->image)); ?>"
                                         src="<?php echo e(asset('/product/'.$product->image)); ?>" alt="img">
                                    <a href="#" class="btn-zoom open_qv"><i class="fa fa-search" aria-hidden="true"></i></a>
                                </div>
                                <div class="product-preview image-small product_preview">
                                    <div id="thumbnails" class="thumbnails_carousel owl-carousel" data-nav="true"
                                         data-autoplay="false" data-dots="false" data-loop="false" data-margin="10"
                                         data-responsive='{"0":{"items":3},"480":{"items":3},"600":{"items":3},"1000":{"items":3}}'>
                                        <a href="#" data-image="<?php echo e(asset('/product/'.$product->image)); ?>"
                                           data-zoom-image="<?php echo e(asset('/product/'.$product->image)); ?>" class="active">
                                            <img src="<?php echo e(asset('/product/'.$product->image)); ?>"
                                                 data-large-image="<?php echo e(asset('/product/'.$product->image)); ?>" alt="img">
                                        </a>
                                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="#" data-image="<?php echo e(asset('/product/'.$image->image)); ?>"
                                               data-zoom-image="<?php echo e(asset('/product/'.$image->image)); ?>">
                                                <img src="<?php echo e(asset('/product/'.$image->image)); ?>"
                                                     data-large-image="<?php echo e(asset('/product/'.$image->image)); ?>" alt="img">
                                            </a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="details-infor">
                                <h1 class="product-title">
                                    <?php echo e($product->name ?? ''); ?>

                                </h1>
                                <div class="stars-rating">
                                    <?php
                                        $sum = 0;
                                        $ratings = \App\Models\RatingWishlist::with('product')->where('product_id', $product->id)->where('type', 'rating')->get();
                                        foreach ($ratings as $rating){
                                            $sum += ceil($rating->rating/count($ratings));
                                        }
                                    ?>
                                    <div class="star-rating">
                                        <?php if($sum > 0): ?>
                                            <span class="star-<?php echo e($sum); ?>"></span>
                                        <?php else: ?>
                                            <span class="star-1"></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="count-star">
                                        (<?php echo e(count($ratings)); ?>)
                                    </div>
                                </div>
                                <div class="availability">
                                    availability:
                                    <a href="#">in Stock</a>
                                </div>
                                <div class="price">
                                    <?php if($product->discount_price): ?>
                                        <del style="font-size: 13px;">
                                            BDT <?php echo e($product->price); ?>

                                        </del>
                                        <span>BDT <?php echo e($product->discount_price ?? ''); ?></span>
                                    <?php endif; ?>
                                    <?php if(!$product->discount_price): ?>
                                            <span>BDT <?php echo e($product->price ?? ''); ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="product-details-description">
                                    <ul>
                                        <li><?php echo e($product->short_description ?? ''); ?></li>
                                    </ul>
                                </div>
                                <?php if($product->colors != null): ?>
                                <div class="variations">
                                    <div class="attribute attribute_size">
                                        <div class="size-text text-attribute">
                                            Color:
                                        </div>
                                        <div class="list-size list-item">
                                            <?php $__currentLoopData = json_decode($product->colors); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color_id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    // dd($color_id);
                                                    $color = App\Models\Color::find($color_id);
                                                    if ($color == null) {
                                                        continue;
                                                    }
                                                ?>

                                                <a href="#" class=""><?php echo e($color->name); ?></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <div class="group-button">
                                    <div class="yith-wcwl-add-to-wishlist">
                                        <div class="yith-wcwl-add-button">
                                            <a href="<?php echo e(url('product/wishlist/add/' . $product->slug)); ?>">Add to Wishlist</a>
                                        </div>
                                    </div>






                                    <form action="<?php echo e(url('/add/to/card')); ?>" method="post" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="quantity-add-to-cart">
                                            <div class="quantity">
                                                <div class="control">
                                                    <a class="btn-number qtyminus quantity-minus" href="#">-</a>
                                                    <input type="text" data-step="1" data-min="0" value="1" name="qty" title="Qty"
                                                           class="input-qty qty" size="4">
                                                    <a href="#" class="btn-number qtyplus quantity-plus">+</a>
                                                </div>
                                            </div>
                                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>" />
                                            <?php if($product->discount_price): ?>
                                                <input type="hidden" name="discount_price" value="<?php echo e($product->discount_price); ?>" />
                                            <?php else: ?>
                                                <input type="hidden" name="price" value="<?php echo e($product->price); ?>" />
                                            <?php endif; ?>
                                            <button class="single_add_to_cart_button button custom-btn-color">Add to cart</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="tab-details-product">
                            <ul class="tab-link">
                                <li class="active">
                                    <a data-toggle="tab" aria-expanded="true" href="#product-descriptions">Descriptions </a>
                                </li>
                                <li class="">
                                    <a data-toggle="tab" aria-expanded="true" href="#information">Information </a>
                                </li>

                            </ul>
                            <div class="tab-container">
                                <div id="product-descriptions" class="tab-panel active">
                                    <p>
                                        <?php echo $product->long_description; ?>

                                    </p>
                                </div>
                                <div id="information" class="tab-panel">
                                    <?php echo $product->information; ?>

                                </div>

                            </div>
                        </div>
                        <div style="clear: left;"></div>
                        <div class="related products product-grid">
                            <h2 class="product-grid-title">You may also like</h2>
                            <div class="owl-products owl-slick equal-container nav-center"  data-slick ='{"autoplay":false, "autoplaySpeed":1000, "arrows":true, "dots":false, "infinite":true, "speed":800, "rows":1}' data-responsive='[{"breakpoint":"2000","settings":{"slidesToShow":3}},{"breakpoint":"1200","settings":{"slidesToShow":2}},{"breakpoint":"992","settings":{"slidesToShow":2}},{"breakpoint":"480","settings":{"slidesToShow":1}}]'>
                                <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="product-item style-1">
                                    <div class="product-inner equal-element">
                                        <div class="product-top">
                                            <div class="flash">
													<span class="onnew">
														<span class="text">
															<?php echo e($data->type); ?>

														</span>
													</span>
                                            </div>
                                        </div>
                                        <div class="product-thumb">
                                            <div class="thumb-inner">
                                                <a href="<?php echo e(url('/product/details/'.$data->id.'/'.$data->slug)); ?>">
                                                    <img src="<?php echo e(asset('/product/'.$data->image)); ?>" alt="img">
                                                </a>
                                                <div class="thumb-group">
                                                    <div class="yith-wcwl-add-to-wishlist">
                                                        <div class="yith-wcwl-add-button">
                                                            <a href="#">Add to Wishlist</a>
                                                        </div>
                                                    </div>
                                                    <a href="#" class="button quick-wiew-button">Quick View</a>
                                                    <div class="loop-form-add-to-cart">
                                                        <button class="single_add_to_cart_button button">Add to cart
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="product-in-stock-wrapp">
        <div class="container">
            <h3 class="custommenu-title-blog white">
                Featured Products
            </h3>
            <div class="stelina-product style3">
                <ul class="row list-products auto-clear equal-container product-grid">
                    <?php $__currentLoopData = $feature_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('frontend.product.includes.feature-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/frontend/product/product-details.blade.php ENDPATH**/ ?>