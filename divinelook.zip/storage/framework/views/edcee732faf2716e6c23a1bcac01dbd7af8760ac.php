

<?php $__env->startPush('style'); ?>

<style>
table,th,  tr, td {
    border: 1px solid #E9ECEF !important;
    border-collapse: collapse !important;
}
</style>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="br-pagetitle">
        <i class="icon ion-tshirt-outline"></i>
        <div>
            <h4>View Products</h4>
            <p class="mg-b-0">
                <a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
                / <a href="<?php echo e(url('admin/product/index')); ?>">Manage Product</a> / View /
            </p>
        </div>
    </div>
    <div class="br-pagebody">
        <div class="br-section-wrapper">
            <div class="table-wrapper table-responsive">
                <table id="" class="table display nowrap" style="width: 99%;">
                    <thead class="thead-colored thead-info">
                    <tr>
                        <th>Product Data</th>
                        <th>Details</th>
                    </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th><strong>category</strong></th>
                            <td><?php echo e($product->category->name ?? ''); ?></td>
                        </tr>
                        <tr>
                            <th><strong>brand</strong></th>
                            <td><?php echo e($product->brand->name); ?></td>
                        </tr>
                        <tr>
                            <th><strong>image</strong></th>
                            <td><img src="<?php echo e(asset('product/' . $product->image)); ?>" width="50" alt=""></td>
                        </tr>
                        <tr>
                            <th><strong>name</strong></th>
                            <td><?php echo e($product->name); ?></td>
                        </tr>
                        <tr>
                            <th><strong>slug</strong></th>
                            <td><?php echo e($product->slug); ?></td>
                        </tr>
                        <tr>
                            <th><strong>sku</strong></th>
                            <td><?php echo e($product->sku); ?></td>
                        </tr>
                        <tr>
                            <th><strong>discount price</strong></th>
                            <td><?php echo e($product->discount_price); ?></td>
                        </tr>
                        <tr>
                            <th><strong>price</strong></th>
                            <td><?php echo e($product->price); ?></td>
                        </tr>
                        <tr>
                            <th><strong>qty</strong></th>
                            <td><?php echo e($product->qty); ?></td>
                        </tr>
                        <tr>
                            <th><strong>short description</strong></th>
                            <td><?php echo e($product->short_description); ?></td>
                        </tr>
                        <tr>
                            <th><strong>long description</strong></th>
                            <td><?php echo e($product->long_description); ?></td>
                        </tr>
                        <tr>
                            <th><strong>information</strong></th>
                            <td><?php echo e($product->information); ?></td>
                        </tr>
                        <tr>
                            <th><strong>type</strong></th>
                            <td><?php echo e($product->type); ?></td>
                        </tr>
                        <tr>
                            <th><strong>features</strong></th>
                            <td><?php echo e($product->features); ?></td>
                        </tr>
                        <tr>
                            <th><strong>avg rating</strong></th>
                            <td><?php echo e($product->avg_rating); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div><!-- table-wrapper -->

        </div><!-- br-section-wrapper -->
    </div><!-- br-pagebody -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/backend/product/view.blade.php ENDPATH**/ ?>