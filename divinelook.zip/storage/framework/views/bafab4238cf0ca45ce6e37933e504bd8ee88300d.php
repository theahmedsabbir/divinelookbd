

<?php $__env->startSection('content'); ?>
    <div class="br-pagetitle">
        <i class="icon ion-star"></i>
        <div>
            <h4>Manage Brand</h4>
            <p class="mg-b-0">
                <a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
                / <a href="<?php echo e(url('admin/brand/create')); ?>">Add Brand</a> / Categories /
            </p>
        </div>
    </div>
    <div class="br-pagebody">
        <div class="br-section-wrapper">
            <div class="table-wrapper table-responsive">
                <table id="datatable3" class="table display nowrap">
                    <thead>
                    <tr>
                        <th class="">#</th>
                        <th class="">Image</th>
                        <th class="">Name</th>
                        <th class="">Slug</th>
                        <th class="notexport">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td>
                                <?php if($brand->image): ?>
                                    <img src="<?php echo e(asset('/brand/'.$brand->image)); ?>" height="50" width="50" />
                                <?php else: ?>
                                    <span>No image found</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($brand->name ?? 'No  name found'); ?></td>
                            <td><?php echo e($brand->slug ?? 'No  slug found'); ?></td>
                            <td>
                                <a href="<?php echo e(url('/admin/brand/edit/'.$brand->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                <a href="<?php echo e(url('/admin/brand/delete/'.$brand->slug)); ?>" onclick="return confirm('Are you sure permanently this brand ?')" class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div><!-- table-wrapper -->

        </div><!-- br-section-wrapper -->
    </div><!-- br-pagebody -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/backend/brand/index.blade.php ENDPATH**/ ?>