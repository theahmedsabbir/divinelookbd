
<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="br-pagetitle">
    <i class="icon ion-ios-list-outline"></i>
    <div>
        <h4>Product Upload From Excel</h4>
        <p class="mg-b-0">
            <a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
            / <a href="<?php echo e(url('admin/product/index')); ?>">Manage Product</a> / Excel Upload /
        </p>
    </div>
</div>

<div class="br-pagebody">
    <div class="br-section-wrapper">
      
      <div class="row">
        <div class="col-md-12">
          <form action="<?php echo e(url('admin/product/store/bulk')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>  

            <div class="row">
              <div class="col-md-6">
                
                  <label for="">Upload excel file</label>
                  <div class="custom-file">
                    <input type="file" name="bulk_file" class="custom-file-input" id="customFile"  accept=".xlsx, .xls, .csv" required>
                    <label class="custom-file-label" for="customFile">Choose file</label>
                  </div>

                  <?php if(session()->has('file_type_error')): ?>
                    <div class="text-danger"><?php echo e(session()->get('file_type_error')); ?></div>
                  <?php endif; ?>

                  <?php if($errors->any()): ?>
  
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                      <div class="text-danger">
                      <?php
                        $errorMsgWords = explode(' ',$error);
                        $sentence = '';
                        // dd($errorMsgWords[1]);
                        if ($errorMsgWords[1] != "selected") {
                          $secondWordArray = explode('.', $errorMsgWords[1]);
                          
                          $row = $secondWordArray[0] + 2;
                          $field = $secondWordArray[1];

                          $sentence .= 'Error at row ' . $row . ' - ';
                          foreach ($errorMsgWords as $key => $errorMsgWord) {
                            if($key == 1){
                              $sentence .= $field . ' ';
                              continue;
                            }
                            $sentence .= $errorMsgWord;
                            $sentence .= ' ';
                          }
                        }else{
                          $secondWordArray = explode('.', $errorMsgWords[2]);
                          
                          $row = $secondWordArray[0] + 2;
                          $field = $secondWordArray[1];

                          $sentence .= 'Error at row ' . $row . ' -';
                          foreach ($errorMsgWords as $key => $errorMsgWord) {
                            if($key == 2){
                              // dd($errorMsgWord);
                              $sentence .= $field;
                              $sentence .= ' ';
                              continue;
                            }
                            $sentence .= $errorMsgWord;
                            $sentence .= ' ';
                          }

                        }
                        echo $sentence;
                      ?>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>

                
              </div>
              <div class="col-md-6">
                <div class="form-group">
                  <label for="">Download sample file</label>
                  <a href="<?php echo e(url('admin/product/create/bulk/sample-file?v=4')); ?>" class="btn d-block text-left " style="
                    border: 1px solid #ced4da;
                    color: #868ba1;
                    position: relative;
                  ">Download <i class="fa fa-download text-right d-inline-block" style="
                    position: absolute;
                    background: #e9ecef;
                    right: 0;
                    display: block;
                    top: 0;
                    padding: 14px 28px;
                    border-left: 1px solid #ced4da;
                  "></i>

                  </a>
                </div>                
              </div>
            </div>


  			<div class="form-group mt-4">
  				<pre class="text-danger">
1. Every field except DISCOUNT PRICE is required
2. NAME should be unique
3. Copy "CATEGORY SLUG" and "BRAND SLUG" from category and brand module 
4. Price and quantity should be numeric and minimum is 0
5. Download the sample file and insert data similarly 
  				</pre>
  			</div>

            <div class="form-group">
              <button type="submit" class="btn btn-teal mt-3">Submit</button>
            </div>
          </form>
        </div>
      </div>
  </div>
    <!-- br-section-wrapper -->
</div>





<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    



<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/backend/product/createBulk.blade.php ENDPATH**/ ?>