<div class="footer-device-mobile">
    <div class="wapper">
        <div class="footer-device-mobile-item device-home">
            <a href="<?php echo e(url('/')); ?>">
					<span class="icon">
						<i class="fa fa-home" aria-hidden="true"></i>
					</span>
                Home
            </a>
        </div>
        <div class="footer-device-mobile-item device-home device-wishlist">
            <a href="#">
					<span class="icon">
						<i class="fa fa-heart" aria-hidden="true"></i>
					</span>
                Wishlist
            </a>
        </div>

        <div class="footer-device-mobile-item device-home device-cart" style="position: relative;">

            <img src="<?php echo e(asset('order/add_to_cart.gif')); ?>" class="add_to_cart_animation_mobile" alt="">
            <a href="<?php echo e(url('/shopping/cart')); ?>">
					<span class="icon">
						<i class="fa fa-shopping-basket" aria-hidden="true"></i>
						<span class="count-icon">
							<?php echo e(count($productCount)); ?>

						</span>
					</span>
                <span class="text">Cart</span>
            </a>
        </div>


        
        <script type="text/javascript">
        <?php if(Session::has('show_cart_animation')): ?>

            setTimeout(function () {
                document.querySelectorAll('.add_to_cart_animation_mobile').forEach((animation)=>{
                    animation.style.display= 'none';
                });
                document.querySelector('.add_to_cart_animation').style.display= 'none';
            }, 3000);
        <?php endif; ?>
        </script>

        <div class="footer-device-mobile-item device-home device-user">
            <?php if(!auth()->check()): ?>
            <a href="<?php echo e(url('/register')); ?>">
					<span class="icon">
						<i class="fa fa-user" aria-hidden="true"></i>
					</span>
                Account
            </a>
            <?php else: ?>
                <a style="cursor: pointer;" onclick="document.querySelector('#logout').submit()">
                    <i class="fa fa-power-off" aria-hidden="true" style="font-size: 25px;"></i>
                </a>
                <form action="<?php echo e(url('logout')); ?>" id="logout" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/frontend/includes/mobile_header.blade.php ENDPATH**/ ?>