<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('/frontend/')); ?>/assets/images/favicon.png"/>
<link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&amp;display=swap"
      rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/css/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/css/animate.min.css">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/css/jquery-ui.css">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/css/slick.css">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/css/chosen.min.css">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/css/pe-icon-7-stroke.css">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/css/magnific-popup.min.css">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/css/lightbox.min.css">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/js/fancybox/source/jquery.fancybox.css">


<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />

<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/css/jquery.scrollbar.min.css">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/css/mobile-menu.css">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/fonts/flaticon/flaticon.css">
<link rel="stylesheet" href="<?php echo e(asset('/frontend/')); ?>/assets/css/style.css">

<link href="<?php echo e(asset('backend/css/toastr.min.css')); ?>" rel="stylesheet">
<?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/frontend/includes/style.blade.php ENDPATH**/ ?>