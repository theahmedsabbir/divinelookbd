

<?php $__env->startSection('content'); ?>
    <div class="br-pagetitle">
        <i class="icon ion-pound"></i>
        <div>
            <h4>Manage Category</h4>
            <p class="mg-b-0">
                <a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
                / <a href="<?php echo e(url('admin/category/create')); ?>">Add Category</a> / Categories /
            </p>
        </div>
    </div>
    <div class="br-pagebody">
        <div class="br-section-wrapper">
            <div class="table-wrapper table-responsive">
                <table id="datatable3" class="table display nowrap">
                    <thead>
                    <tr>
                        <th class="">#</th>
                        <th class="">Image</th>
                        <th class="">Name</th>
                        <th class="">Slug</th>
                        <th class="notexport">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index+1); ?></td>
                            <td>
                                <?php if($category->image): ?>
                                    <img src="<?php echo e(asset('/category/'.$category->image)); ?>" height="50" width="50" />
                                <?php else: ?>
                                    <span>No image found</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($category->name ?? 'No  name found'); ?></td>
                            <td><?php echo e($category->slug ?? 'No  slug found'); ?></td>
                            <td>
                                <a href="<?php echo e(url('/admin/category/edit/'.$category->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                <a href="<?php echo e(url('/admin/category/delete/'.$category->slug)); ?>" onclick="return confirm('Are you sure permanently this category ?')" class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div><!-- table-wrapper -->

        </div><!-- br-section-wrapper -->
    </div><!-- br-pagebody -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/backend/category/index.blade.php ENDPATH**/ ?>