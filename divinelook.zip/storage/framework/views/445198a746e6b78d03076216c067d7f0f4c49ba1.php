
<meta charset="utf-8">
<link rel="icon" href="<?php echo e(asset('backend/images/icon_short.png')); ?>" type="image/x-icon" />
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


<title>Divinlook | Admin</title>
<?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/backend/includes/header.blade.php ENDPATH**/ ?>