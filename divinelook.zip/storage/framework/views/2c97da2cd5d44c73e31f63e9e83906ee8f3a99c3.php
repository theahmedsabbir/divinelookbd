

<style>
    h5.modal-title {font-size: 22px;
    font-weight: 500;
    line-height: 1.2;
    /* max-width: 370px; */
    text-transform: capitalize;width: 100%;}

    button.close.text-right {color: #000 !important;opacity: 1;}

    .modal-header {border: none;}

    .modal-header {padding-bottom: 7px;}


    .carousel-caption h3 {color: white;font-size: 34px;background: #0000002b;margin: 0;}

    .carousel-caption p {font-size: 24px;background: #0000002b;padding-bottom: 13px;}
    .modal-body.p-0 {padding: 0 !important;}
    .modal-content {background: transparent !important;}

    @media (min-width: 992px) { 

        .modal_box{
            width: 75% !important;
            height: 75% !important;
        }
    }
</style>


<div id="myModal" class="modal fade">
    <div class="modal-dialog modal-lg  modal-dialog-centered modal_box" >
        <div class="modal-content">

            <div class="modal-body p-0">
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <!-- Indicators -->


                    <!-- Wrapper for slides -->
                    <div class="carousel-inner">

                        <?php
                            $popups = App\Models\Banner::where('type','popup')
                                                    ->orderBy('priority', 'asc')
                                                    ->get();
                        ?>                  

                        <?php $__currentLoopData = $popups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $popup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item 
                            <?php if($key == 0): ?>
                                active
                            <?php endif; ?>
                        ">
                            <img src="<?php echo e(asset('banner/' . $popup->image)); ?>" alt="<?php echo e($popup->title); ?>" style="width:100%;" class="carousel_img">
                            <div class="carousel-caption">
                                <?php if($popup->title): ?>
                                    <h3><?php echo e($popup->title); ?></h3>
                                <?php endif; ?>
                                <?php if($popup->sub_title): ?>
                                    <p><?php echo e($popup->sub_title); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                    </div>

                    <!-- Left and right controls -->
                    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                        <span class="glyphicon glyphicon-chevron-left"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="right carousel-control" href="#myCarousel" data-slide="next">
                        <span class="glyphicon glyphicon-chevron-right"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/frontend/includes/popup.blade.php ENDPATH**/ ?>