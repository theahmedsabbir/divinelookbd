    


    <div class="product-inner equal-element">
        <?php if($product->type): ?>
        <div class="product-top">
            <div class="flash">
					<span class="onnew">
						<span class="text">
							<?php echo e($product->type); ?>

						</span>
					</span>
            </div>
        </div>
        <?php endif; ?>
        <div class="product-thumb">
            <div class="thumb-inner">
                <a href="<?php echo e(url('/product/details/'. $product->id . '/'. $product->slug)); ?>">
                    <img src="<?php echo e(asset('product/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>">
                </a>
                <div class="thumb-group">
                    <div class="yith-wcwl-add-to-wishlist">
                        <div class="yith-wcwl-add-button">
                            <?php if(Request::url() == url('product/wishlist')): ?>
                                <a class="wishlist-remove" href="<?php echo e(url('product/wishlist/remove/' . $product->slug)); ?>">Remove from Wishlist</a>
                            <?php else: ?>
                                <a href="<?php echo e(url('product/wishlist/add/' . $product->slug)); ?>">Add to Wishlist</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="loop-form-add-to-cart">
                        <a class="single_add_to_cart_button button"
                            style="cursor: pointer" 
                            onclick="show_animation_add_to_cart(<?php echo e($product->id); ?>)" 
                            
                        >Add to cart
                        </a>

                        <script>
                            function show_animation_add_to_cart(product_id){


                                document.querySelector('.add_to_cart_animation').style.display= 'block';
                                window.location.href= "<?php echo e(url('order/add-to-cart/' )); ?>/"+product_id;

                            }
                        </script>
                    </div>
                </div>
            </div>
        </div>
        <div class="product-info">
            <h5 class="product-name product_title">
                <a href="<?php echo e(url('/product/details/'. $product->id . '/'. $product->slug)); ?>"><?php echo e($product->name); ?></a>
            </h5>
            <div class="group-info">
                <div class="stars-rating">
                    <?php
                        $sum = 0;
                        $ratings = \App\Models\RatingWishlist::with('product')->where('product_id', $product->id)->where('type', 'rating')->get();
                        foreach ($ratings as $rating){
                            $sum += ceil($rating->rating/count($ratings));
                        }
                    ?>
                    <div class="star-rating">
                        <?php if($sum > 0): ?>
                        <span class="star-<?php echo e($sum); ?>"></span>
                        <?php else: ?>
                            <span class="star-5"></span>
                        <?php endif; ?>
                    </div>
                    <div class="count-star">
                        (<?php echo e(count($ratings)); ?>)
                    </div>
                </div>
                <div class="price">
                	<?php if($product->discount_price): ?>
                    <del>
                        ৳<?php echo e($product->discount_price ?? ''); ?>

                    </del>
                	<?php endif; ?>
                    <ins>
                        ৳<?php echo e($product->price); ?>

                    </ins>
                </div>
                <button class="single_add_to_cart_button button custom-btn-color" style="margin: 10px auto;"
                    onclick="window.location.href='<?php echo e(url('/order/add-to-cart/' . $product->id)); ?>'" 
                >
                    Add to cart
                </button>
            </div>
        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/frontend/product/includes/product-card.blade.php ENDPATH**/ ?>