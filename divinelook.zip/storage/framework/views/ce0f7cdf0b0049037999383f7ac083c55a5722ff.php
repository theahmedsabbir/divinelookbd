
<?php $__env->startPush('style'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="br-pagetitle">
        <i class="icon ion-tshirt-outline"></i>
        <div>
            <h4>Add Product</h4>
            <p class="mg-b-0">
                <a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
                / <a href="<?php echo e(url('admin/product/index')); ?>">Manage Product</a> / Add Product /
            </p>
        </div>
    </div>
    <div class="br-pagebody">
        <div class="br-section-wrapper">
            <form action="<?php echo e(url('/admin/product/store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <div class="row">
                        <div class="col">
                            <label for="name">Name</label>
                            <input type="text" name="name" id="name" class="form-control" placeholder="Product name" required>
                        </div>
                        <div class="col">
                            <label for="sku">SKU</label>
                            <input type="text" name="sku" id="sku" class="form-control" placeholder="Product sku name" required>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col">
                            <label for="cat_id">Category Name</label>
                            <select class="form-control" name="cat_id" id="cat_id" required>
                                <option selected disabled>Select a category</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php if($errors->has('cat_id')): ?>
                                <p class="text-danger"><?php echo e($errors->first('cat_id')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="col">
                            <label for="brand_id">Brand Name</label>
                            <select class="form-control" name="brand_id" id="brand_id" required>
                                <option selected disabled>Select a brand</option>
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php if($errors->has('brand_id')): ?>
                                <p class="text-danger"><?php echo e($errors->first('brand_id')); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col">
                            <label for="price">Price</label>
                            <input type="number" class="form-control" name="price" id="price" placeholder="Enter product price" required />
                        </div>
                        <div class="col">
                            <label for="discount_price">Discount Price ( <small class="text-danger">Optional</small> )</label>
                            <input type="number" min="0" step="0.01" class="form-control" name="discount_price" id="discount_price" placeholder="Enter discount price" />
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col">
                            <label for="qty">Qty</label>
                            <input type="number" class="form-control" name="qty" id="qty" placeholder="Enter product qty" />
                        </div>
                        <div class="col">
                            <label for="colors">Color Family</label>
                            <select class="form-control select2" name="colors[]" id="colors" multiple>
                                <option selected disabled>Select a color family</option>
                                <?php $__currentLoopData = App\Models\Color::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($color->id); ?>"><?php echo e($color->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php if($errors->has('colors')): ?>
                                <p class="text-danger"><?php echo e($errors->first('colors')); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col">
                            <label for="short_description">Short description</label>
                            <textarea class="form-control" rows="5" name="short_description" id="short_description" placeholder="Enter product short description" required></textarea>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col">
                            <label for="long_description">Long description</label>
                            <textarea class="form-control summernote" rows="5" name="long_description" id="long_description" placeholder="Enter product long description"></textarea>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col">
                            <label for="information">Information</label>
                            <textarea class="form-control summernote" rows="5" name="information" id="information" placeholder="Enter product information"></textarea>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col">
                            <label for="type">Type</label>
                            <select class="form-control" name="type" id="type">
                                <option selected disabled>Select product type</option>
                                <option value="hot">Hot</option>
                                <option value="discount">Discount</option>
                                <option value="new">New</option>
                            </select>
                        </div>
                        <div class="col">
                            <label for="features">Feature</label>
                            <select class="form-control" name="features" id="features">
                                <option selected disabled>Enter product feature</option>
                                <option value="featured">Featured Products</option>
                                <option value="best_seller">Best Seller</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col">
                            <label for="image">Image</label>
                            <input type="file" name="image" id="image" class="form-control" placeholder="Product image" required>

                            <?php if($errors->has('image')): ?>
                                <p class="text-danger"><?php echo e($errors->first('image')); ?></p>
                            <?php endif; ?>
                        </div>
                        <div class="col">
                            <label for="images">Multiple images</label>
                            <input type="file" name="images[]" id="images" class="form-control" multiple placeholder="Product images" required>

                            <?php if($errors->has('images.*')): ?>
                                <p class="text-danger"><?php echo e($errors->first('images.*')); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-12">                            
                            <button type="submit" name="btn" class="btn btn-md btn-success mt-3">Submit</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div><!-- br-pagebody -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    



<?php $__env->stopPush(); ?>


<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/backend/product/create.blade.php ENDPATH**/ ?>