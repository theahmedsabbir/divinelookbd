
    <div class="br-logo"><a href="<?php echo e(url('admin/dashboard')); ?>">
      <img src="<?php echo e(asset('/frontend/')); ?>/assets/images/logo-side.png" alt="img" style="">
      
    </div>
    <div class="br-sideleft sideleft-scrollbar">
      <label class="sidebar-label pd-x-10 mg-t-25 mg-b-20 tx-info">Navigation</label>
      <ul class="br-sideleft-menu">
        <li class="br-menu-item">
          <a href="<?php echo e(url('admin/dashboard')); ?>" class="br-menu-link <?php echo e(Request::is('admin/dashboard') ? 'active' : ''); ?>">
            <i class="menu-item-icon icon ion-ios-home-outline tx-24"></i>
            <span class="menu-item-label">Dashboard</span>
          </a><!-- br-menu-link -->
        </li><!-- br-menu-item -->

        <label class="sidebar-label pd-x-10 mg-t-25 mg-b-20 tx-info">Manage Users</label>

        
        <li class="br-menu-item">
          <a href="#" class="br-menu-link with-sub <?php echo e(Request::is('admin/user*') ? 'show-sub' : ''); ?>">
            <i class="menu-item-icon icon ion-person-stalker tx-24"></i>
            
            <span class="menu-item-label">Users</span>
          </a><!-- br-menu-link -->
          <ul class="br-menu-sub" style="<?php echo e(Request::is('admin/user*') ? 'display: block;' : 'display: none;'); ?>">

            <li class="sub-item">
              <a href="<?php echo e(url('admin/user/index')); ?>" class="sub-link <?php echo e(Request::is('admin/user/index') ? 'active' : ''); ?>">Manage</a>
            </li>
          </ul>
        </li>


        <label class="sidebar-label pd-x-10 mg-t-25 mg-b-20 tx-info">Manage Products</label>

          
          <li class="br-menu-item">
            <a href="#" class="br-menu-link with-sub <?php echo e(Request::is('admin/category*') ? 'show-sub' : ''); ?>">
              <i class="menu-item-icon icon ion-pound tx-24"></i>
              
              <span class="menu-item-label">Category</span>
            </a><!-- br-menu-link -->
            <ul class="br-menu-sub" style="<?php echo e(Request::is('admin/category*') ? 'display: block;' : 'display: none;'); ?>">

              <li class="sub-item">
                <a href="<?php echo e(url('admin/category/index')); ?>" class="sub-link <?php echo e(Request::is('admin/category/index') ? 'active' : ''); ?>">Manage</a>
              </li>
              <li class="sub-item">
                <a href="<?php echo e(url('admin/category/create')); ?>" class="sub-link <?php echo e(Request::is('admin/category/create') ? 'active' : ''); ?>">Add</a>
              </li>
            </ul>
          </li>

          
          <li class="br-menu-item">
            <a href="#" class="br-menu-link with-sub <?php echo e(Request::is('admin/brand*') ? 'show-sub' : ''); ?>">
              <i class="menu-item-icon icon ion-star tx-24"></i>
              
              <span class="menu-item-label">Brand</span>
            </a><!-- br-menu-link -->
            <ul class="br-menu-sub" style="<?php echo e(Request::is('admin/brand*') ? 'display: block;' : 'display: none;'); ?>">

              <li class="sub-item">
                <a href="<?php echo e(url('admin/brand/index')); ?>" class="sub-link <?php echo e(Request::is('admin/brand/index') ? 'active' : ''); ?>">Manage</a>
              </li>
              <li class="sub-item">
                <a href="<?php echo e(url('admin/brand/create')); ?>" class="sub-link <?php echo e(Request::is('admin/brand/create') ? 'active' : ''); ?>">Add</a>
              </li>
            </ul>
          </li>

          <li class="br-menu-item">
            <a href="#" class="br-menu-link with-sub <?php echo e(Request::is('admin/product*') ? 'show-sub' : ''); ?>">
              <i class="menu-item-icon icon ion-tshirt-outline tx-24"></i>
              
              <span class="menu-item-label">Product</span>
            </a><!-- br-menu-link -->
            <ul class="br-menu-sub" style="<?php echo e(Request::is('admin/product*') ? 'display: block;' : 'display: none;'); ?>">

              <li class="sub-item">
                <a href="<?php echo e(url('admin/product/index')); ?>" class="sub-link <?php echo e(Request::is('admin/product/index') ? 'active' : ''); ?>">Manage</a>
              </li>
              <li class="sub-item">
                <a href="<?php echo e(url('admin/product/create')); ?>" class="sub-link <?php echo e(Request::is('admin/product/create') ? 'active' : ''); ?>">Add</a>
              </li>
            </ul>
          </li>


          <li class="br-menu-item">
            <a href="#" class="br-menu-link with-sub <?php echo e(Request::is('admin/product/create/bulk*') ? 'show-sub' : ''); ?>">
              <i class="menu-item-icon icon ion-ios-list-outline tx-24"></i>
              
              <span class="menu-item-label">Excel Upload</span>
            </a><!-- br-menu-link -->
            <ul class="br-menu-sub" style="<?php echo e(Request::is('admin/product*') ? 'display: block;' : 'display: none;'); ?>">


              <li class="sub-item">
                <a href="<?php echo e(url('admin/product/create/bulk')); ?>" class="sub-link <?php echo e(Request::is('admin/product/create/bulk') ? 'active' : ''); ?>">Manage</a>
              </li>
            </ul>
          </li>



          <label class="sidebar-label pd-x-10 mg-t-25 mg-b-20 tx-info">Manage Orders</label>

          <li class="br-menu-item">
              <a href="#" class="br-menu-link with-sub <?php echo e(Request::is('admin/order*') ? 'show-sub' : ''); ?>">
                  <i class="menu-item-icon icon ion-ios-cart-outline tx-24"></i>
                  
                  <span class="menu-item-label">Order</span>
              </a><!-- br-menu-link -->
              <ul class="br-menu-sub" style="<?php echo e(Request::is('admin/order*') ? 'display: block;' : 'display: none;'); ?>">

                  <li class="sub-item">
                      <a href="<?php echo e(url('admin/order/index')); ?>" class="sub-link <?php echo e(Request::is('admin/order/index') ? 'active' : ''); ?>">Manage</a>
                  </li>
              </ul>
          </li>

          <li class="br-menu-item">
              <a href="#" class="br-menu-link with-sub <?php echo e(Request::is('admin/stock*') ? 'show-sub' : ''); ?>">
                  <i class="menu-item-icon icon ion-compose tx-24"></i>
                  
                  <span class="menu-item-label">Stock Report</span>
              </a><!-- br-menu-link -->
              <ul class="br-menu-sub" style="<?php echo e(Request::is('admin/order*') ? 'display: block;' : 'display: none;'); ?>">

                  <li class="sub-item">
                      <a href="<?php echo e(url('admin/stock/index')); ?>" class="sub-link <?php echo e(Request::is('admin/stock/index') ? 'active' : ''); ?>">Manage</a>
                  </li>
              </ul>
          </li>

          <label class="sidebar-label pd-x-10 mg-t-25 mg-b-20 tx-info">Manage Accounts</label>


          <li class="br-menu-item">
            <a href="#" class="br-menu-link with-sub <?php echo e(Request::is('admin/report*') ? 'show-sub' : ''); ?>">
              <i class="menu-item-icon ion-stats-bars tx-20"></i>
              <span class="menu-item-label">Reports</span>
            </a><!-- br-menu-link -->
            <ul class="br-menu-sub" style="<?php echo e(Request::is('admin/report*') ? 'display: block;' : 'display: none;'); ?>">

              <li class="sub-item">
                <a href="<?php echo e(url('admin/report/sales')); ?>" class="sub-link <?php echo e(Request::is('admin/report/sales') ? 'active' : ''); ?>">Sales Report</a>

                <a href="<?php echo e(url('admin/report/sales-by-product')); ?>" class="sub-link <?php echo e(Request::is('admin/report/sales-by-product') ? 'active' : ''); ?>">Sales By Product</a>

                <a href="<?php echo e(url('admin/report/customer')); ?>" class="sub-link <?php echo e(Request::is('admin/report/customer') ? 'active' : ''); ?>">Customer Report</a>


              </li>

            </ul>
          </li>

          <label class="sidebar-label pd-x-10 mg-t-25 mg-b-20 tx-info">Settings</label>

          
          <li class="br-menu-item">
            <a href="#" class="br-menu-link with-sub <?php echo e(Request::is('admin/banner/slider*') ? 'show-sub' : ''); ?>">
              <i class="menu-item-icon icon ion-navicon-round tx-24"></i>
              
              <span class="menu-item-label">Sliders</span>
            </a><!-- br-menu-link -->
            <ul class="br-menu-sub" style="<?php echo e(Request::is('admin/banner/slider*') ? 'display: block;' : 'display: none;'); ?>">

              <li class="sub-item">
                <a href="<?php echo e(url('admin/banner/slider/index')); ?>" class="sub-link <?php echo e(Request::is('admin/banner/slider/index') ? 'active' : ''); ?>">Manage</a>
              </li>
              <li class="sub-item">
                <a href="<?php echo e(url('admin/banner/slider/create')); ?>" class="sub-link <?php echo e(Request::is('admin/banner/slider/create') ? 'active' : ''); ?>">Add</a>
              </li>
            </ul>
          </li>

          
          <li class="br-menu-item">
            <a href="#" class="br-menu-link with-sub <?php echo e(Request::is('admin/banner/side-banner*') ? 'show-sub' : ''); ?>">
              <i class="menu-item-icon icon ion-arrow-right-c tx-24"></i>
              
              <span class="menu-item-label">Side Banners</span>
            </a><!-- br-menu-link -->
            <ul class="br-menu-sub" style="<?php echo e(Request::is('admin/banner/side-banner*') ? 'display: block;' : 'display: none;'); ?>">

              <li class="sub-item">
                <a href="<?php echo e(url('admin/banner/side-banner/index')); ?>" class="sub-link <?php echo e(Request::is('admin/banner/side-banner/index') ? 'active' : ''); ?>">Manage</a>
              </li>
              <li class="sub-item">
                <a href="<?php echo e(url('admin/banner/side-banner/create')); ?>" class="sub-link <?php echo e(Request::is('admin/banner/side-banner/create') ? 'active' : ''); ?>">Add</a>
              </li>
            </ul>
          </li>

          
          <li class="br-menu-item">
            <a href="#" class="br-menu-link with-sub <?php echo e(Request::is('admin/banner/mid-banner*') ? 'show-sub' : ''); ?>">
              <i class="menu-item-icon icon ion-arrow-down-c tx-24"></i>
              
              <span class="menu-item-label">Mid Banners</span>
            </a><!-- br-menu-link -->
            <ul class="br-menu-sub" style="<?php echo e(Request::is('admin/banner/mid-banner*') ? 'display: block;' : 'display: none;'); ?>">

              <li class="sub-item">
                <a href="<?php echo e(url('admin/banner/mid-banner/index')); ?>" class="sub-link <?php echo e(Request::is('admin/banner/mid-banner/index') ? 'active' : ''); ?>">Manage</a>
              </li>
              <li class="sub-item">
                <a href="<?php echo e(url('admin/banner/mid-banner/create')); ?>" class="sub-link <?php echo e(Request::is('admin/banner/mid-banner/create') ? 'active' : ''); ?>">Add</a>
              </li>
            </ul>
          </li>

          
          <li class="br-menu-item">
            <a href="#" class="br-menu-link with-sub <?php echo e(Request::is('admin/banner/full-banner*') ? 'show-sub' : ''); ?>">
              <i class="menu-item-icon icon ion-arrow-swap tx-24"></i>
              
              <span class="menu-item-label">Full Banners</span>
            </a><!-- br-menu-link -->
            <ul class="br-menu-sub" style="<?php echo e(Request::is('admin/banner/full-banner*') ? 'display: block;' : 'display: none;'); ?>">

              <li class="sub-item">
                <a href="<?php echo e(url('admin/banner/full-banner/index')); ?>" class="sub-link <?php echo e(Request::is('admin/banner/full-banner/index') ? 'active' : ''); ?>">Manage</a>
              </li>
              <li class="sub-item">
                <a href="<?php echo e(url('admin/banner/full-banner/create')); ?>" class="sub-link <?php echo e(Request::is('admin/banner/full-banner/create') ? 'active' : ''); ?>">Add</a>
              </li>
            </ul>
          </li>

          
          <li class="br-menu-item">
            <a href="#" class="br-menu-link with-sub <?php echo e(Request::is('admin/banner/popup*') ? 'show-sub' : ''); ?>">
              <i class="menu-item-icon icon ion-arrow-expand tx-24"></i>
              
              <span class="menu-item-label">Popups</span>
            </a><!-- br-menu-link -->
            <ul class="br-menu-sub" style="<?php echo e(Request::is('admin/banner/popup*') ? 'display: block;' : 'display: none;'); ?>">

              <li class="sub-item">
                <a href="<?php echo e(url('admin/banner/popup/index')); ?>" class="sub-link <?php echo e(Request::is('admin/banner/popup/index') ? 'active' : ''); ?>">Manage</a>
              </li>
              <li class="sub-item">
                <a href="<?php echo e(url('admin/banner/popup/create')); ?>" class="sub-link <?php echo e(Request::is('admin/banner/popup/create') ? 'active' : ''); ?>">Add</a>
              </li>
            </ul>
          </li>

          
          <li class="br-menu-item">
            <a href="#" class="br-menu-link with-sub <?php echo e(Request::is('admin/banner/gallery*') ? 'show-sub' : ''); ?>">
              <i class="menu-item-icon icon ion-images tx-24"></i>
              
              <span class="menu-item-label">Gallery</span>
            </a><!-- br-menu-link -->
            <ul class="br-menu-sub" style="<?php echo e(Request::is('admin/banner/gallery*') ? 'display: block;' : 'display: none;'); ?>">

              <li class="sub-item">
                <a href="<?php echo e(url('admin/banner/gallery/index')); ?>" class="sub-link <?php echo e(Request::is('admin/banner/gallery/index') ? 'active' : ''); ?>">Manage</a>
              </li>
              <li class="sub-item">
                <a href="<?php echo e(url('admin/banner/gallery/create')); ?>" class="sub-link <?php echo e(Request::is('admin/banner/gallery/create') ? 'active' : ''); ?>">Add</a>
              </li>
            </ul>
          </li>

      </ul><!-- br-sideleft-menu -->
      <br>
    </div><!-- br-sideleft -->
<?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/backend/includes/left_sidebar.blade.php ENDPATH**/ ?>