
<link href="<?php echo e(asset('backend/lib/@fortawesome/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('backend/lib/ionicons/css/ionicons.min.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('backend/lib/select2/css/select2.min.css')); ?>" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset('backend/css/jquery.dataTables.min.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(asset('backend/css/buttons.dataTables.min.css')); ?>">  



<link href="<?php echo e(asset('backend/lib/medium-editor/css/medium-editor.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('backend/lib/medium-editor/css/themes/default.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('backend/lib/summernote/summernote-bs4.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('backend/css/toastr.min.css')); ?>" rel="stylesheet">



<!-- Bracket CSS -->
<link rel="stylesheet" href="<?php echo e(asset('backend/css/bracket.css')); ?>">

<style>
	.dataTables_wrapper{
		width: 99% !important;
	}
	#datatable3 th{
		padding-right: 30px;
	}
	label,th,option{
		text-transform: capitalize;
	}
</style>
<?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/backend/includes/css.blade.php ENDPATH**/ ?>