

<?php $__env->startSection('content'); ?>
    <div class="br-pagetitle">
        <i class="icon ion-tshirt-outline"></i>
        <div>
            <h4>Manage Products</h4>
            <p class="mg-b-0">
                <a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
                / <a href="<?php echo e(url('admin/product/create')); ?>">Add Product</a> / Products /
            </p>
        </div>
    </div>
    <div class="br-pagebody">
        <div class="br-section-wrapper">
            <div class="table-wrapper table-responsive">
                <table id="datatable3" class="table display nowrap">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Category</th>
                        <th>Brand</th>
                        <th>Price</th>
                        <th class="notexport">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = App\Models\Product::orderBy('id', 'desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td>
                                <img src="<?php echo e(asset('product/' . $product->image)); ?>" width="50" alt="">
                            </td>
                            <td><?php echo e($product->name); ?></td>
                            <td><?php echo e($product->category->name ?? ''); ?></td>
                            <td><?php echo e($product->brand->name ?? ''); ?></td>
                            <td><?php echo e($product->price ?? ''); ?></td>
                            <td>
                                <a href="<?php echo e(url('/admin/product/view/'. encrypt($product->id))); ?>" class="btn btn-sm btn-success">View</a>
                                <a href="<?php echo e(url('/admin/product/edit/'.encrypt($product->id))); ?>" class="btn btn-sm btn-info">Edit</a>
                                <a href="<?php echo e(url('/admin/product/delete/'.encrypt($product->id))); ?>" onclick="return confirm('Are you sure permanently this category ?')" class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div><!-- table-wrapper -->

        </div><!-- br-section-wrapper -->
    </div><!-- br-pagebody -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/backend/product/index.blade.php ENDPATH**/ ?>