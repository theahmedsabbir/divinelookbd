


<?php $__env->startPush('style'); ?>
<style type="text/css">
        /* Extra small devices (phones, 600px and down) */
    @media  only screen and (max-width: 600px) {
        .slider-inner{  height: 236px;  }
    }

    /* Small devices (portrait tablets and large phones, 600px and up) */
    @media  only screen and (min-width: 600px) {

        .slider-inner{  height: 434px;  }
    }

    /* Medium devices (landscape tablets, 768px and up) */
    @media  only screen and (min-width: 768px) {

    }

    /* Large devices (laptops/desktops, 992px and up) */
    @media  only screen and (min-width: 992px) {        
        /*.slider-inner{  height: 611px;  }*/
    }

    /* Extra large devices (large laptops and desktops, 1200px and up) */
    @media  only screen and (min-width: 1200px) {
        .slider-inner{  height: 652px;  }
    }
</style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>

    <div>
        <div class="fullwidth-template">
            <div class="home-slider-banner">
                <div class="container">
                    <div class="row10">
                        <div class="col-lg-8 silider-wrapp">
                            <div class="home-slider">
                                <div class="slider-owl owl-slick equal-container nav-center"
                                     data-slick='{"autoplay":true, "autoplaySpeed":9000, "arrows":false, "dots":true, "infinite":true, "speed":1000, "rows":1}'
                                     data-responsive='[{"breakpoint":"2000","settings":{"slidesToShow":1}}]'>

                                    <?php $__currentLoopData = App\Models\Banner::where('type', 'slider')
                                                            ->orderBy('priority', 'asc')
                                                            ->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                     

                                    <div class="slider-item style7">
                                        <div class="slider-inner"
                                            style="background-image: url(<?php echo e(url('banner/' . $slider->image)); ?>); "
                                        >
                                            <div class="slider-infor">
                                                <h5 class="title-small">
                                                    <?php echo $slider->info; ?>

                                                </h5>
                                                <h3 class="title-big">
                                                    <?php echo $slider->title; ?>

                                                </h3>
                                                <div class="price">
                                                    <?php echo $slider->sub_title; ?>

                                                </div>
                                                <a href="<?php echo e($slider->link); ?>" class="button btn-shop-the-look bgroud-style"><?php echo e($slider->button_text); ?></a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>

                        <?php
                            $sideBanners = App\Models\Banner::where('type', 'side-banner')
                                                    ->orderBy('priority', 'asc')
                                                    ->get();
                        ?>

                        <?php if($sideBanners->count() == 2): ?>
                        <div class="col-lg-4 banner-wrapp">
                            <?php $__currentLoopData = $sideBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $sideBanner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="banner">
                                <div class="item-banner style7">
                                    <div class="inner"
                                            style="
                                                background-image: url(<?php echo e(url('banner/' . $sideBanner->image)); ?>);
                                                background-size: cover;

                                            "
                                    >
                                        <div class="banner-content">
                                            <h3 class="title"><?php echo $sideBanner->title; ?></h3>
                                            <div class="description">
                                                <?php echo $sideBanner->sub_title; ?>

                                            </div>
                                            <?php if($key== 1): ?>
                                                <br>
                                            <?php endif; ?>
                                            <a href="<?php echo e($sideBanner->link); ?>" class="button btn-lets-do-it"><?php echo e($sideBanner->button_text); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            
            <?php if($all_category_products->count() > 0): ?>
            <div class="stelina-tabs  default rows-space-40">
                <div class="container">
                    <div class="tab-head">
                        <ul class="tab-link">
                            <?php $__currentLoopData = $all_category_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $all_category_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="<?php echo e($key == 0 ? 'active' : ''); ?>">
                                    <a data-toggle="tab" aria-expanded="true" href="#<?php echo e($all_category_product['category']->slug); ?>"><?php echo e($all_category_product['category']->name); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="tab-container">
                        <?php $__currentLoopData = $all_category_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $all_category_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div id="<?php echo e($all_category_product['category']->slug); ?>" class="tab-panel <?php echo e($key == 0 ? 'active' : ''); ?>">
                            <div class="stelina-product">
                                <ul class="row list-products auto-clear equal-container product-grid">
                                    <?php $__currentLoopData = $all_category_product['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current_category_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="product-item  col-lg-3 col-md-4 col-sm-6 col-xs-6 col-ts-12 style-1">
                                        <?php echo $__env->make('frontend.product.includes.product-card', ['product' => $current_category_product], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>



            <?php
                $midBanners = App\Models\Banner::where('type', 'mid-banner')
                                        ->orderBy('priority', 'asc')
                                        ->get();
            ?>

            <?php if($midBanners->count() == 2): ?>
            <div class="banner-wrapp">
                <div class="container">
                    <div class="row">
                        <?php $__currentLoopData = $midBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $midBanner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="banner">
                                <div class="item-banner style4">
                                    <div class="inner"

                                            style="
                                                background-image: url(<?php echo e(url('banner/' . $midBanner->image)); ?>);
                                                background-size: cover;

                                            "
                                    >
                                        <div class="banner-content">
                                            <h4 class="stelina-subtitle"><?php echo $midBanner->info; ?></h4>
                                            <h3 class="title"><?php echo $midBanner->title; ?></h3>
                                            <div class="description">
                                                <?php echo $midBanner->sub_title; ?>

                                            </div>
                                            <a href="<?php echo e($midBanner->link); ?>" class="button btn-shop-now"><?php echo e($midBanner->button_text); ?></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>


            <?php
                $fullBanner = App\Models\Banner::where('type', 'full-banner')
                                        ->first();
            ?>

            <?php if($fullBanner): ?>
            <div class="banner-wrapp rows-space-65">
                <div class="container">
                    <div class="banner">
                        <div class="item-banner style17">
                            <div class="inner">
                                <div class="banner-content">
                                    <h3 class="title"><?php echo $fullBanner->title; ?></h3>
                                    <div class="description">
                                        <?php echo $fullBanner->info; ?>

                                    </div>
                                    <div class="banner-price">
                                        <?php echo $fullBanner->sub_title; ?>

                                    </div>
                                    <a href="<?php echo e($fullBanner->link); ?>" class="button btn-shop-now">
                                        <?php echo $fullBanner->button_text; ?>

                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="product-in-stock-wrapp">
                <div class="container">
                    <h3 class="custommenu-title-blog white">
                        Featured Products
                    </h3>
                    <div class="stelina-product style3">
                        <ul class="row list-products auto-clear equal-container product-grid">
                            <?php $__currentLoopData = $feature_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('frontend.product.includes.feature-product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/frontend/home/index.blade.php ENDPATH**/ ?>