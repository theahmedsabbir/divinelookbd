

<?php $__env->startSection('content'); ?>
    <div class="br-pagetitle">
        <i class="icon ion-star"></i>
        <div>
            <h4>Add Brand</h4>
            <p class="mg-b-0">
                <a href="<?php echo e(url('admin/dashboard')); ?>">Dashboard</a>
                / <a href="<?php echo e(url('admin/brand/index')); ?>">Manage Brand</a> / Add Brand /
            </p>
        </div>
    </div>
    <div class="br-pagebody">
        <div class="br-section-wrapper">
            <div class="row">
                <?php if($page == 'create' || $page == 'edit'): ?>
                <div class="col-md-12">
                    <form action="<?php echo e($page == 'edit' ? url('admin/brand/update/'.$brand->id) : url('admin/brand/store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="">Name</label>
                            <input type="text" name="name" value="<?php echo e($brand->name ?? old('name')); ?>" class="form-control" placeholder="Brand name" required>
                            <?php if($errors->has('name')): ?>
                                <div class="text-danger"><?php echo e($errors->first('name')); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="">Image</label>
                            <input type="file" name="image" value="" class="form-control" onchange="imagePreview(event)">
                            <img src="" id="pre-logo"/>
                            <?php if(!empty($brand->image)): ?>
                                <img src="<?php echo e(asset('/brand/'.$brand->image)); ?>" height="100" width="100"/>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-teal mt-3">Submit</button>
                        </div>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div><!-- br-pagebody -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        function imagePreview(e){
            if (e.target.files[0]) {
                let image = e.target.files[0];
                if(image['type'] === 'image/jpeg' || image['type'] === 'image/png' || image['type'] === 'image/webp' || image['type'] === 'image/gif'){
                    let reader = new FileReader();
                    reader.onload = function ()
                    {
                        let output = document.getElementById('pre-logo');
                        output.src = reader.result;
                        output.style.display = "block";
                        output.style.width = "10%";
                    }
                    reader.readAsDataURL(event.target.files[0]);
                }else{
                   alert('This is not image file. Please input e valid image.');
                }
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/backend/brand/create.blade.php ENDPATH**/ ?>