<header class="header style7">
    <div class="top-bar">
        <div class="container">
            <div class="top-bar-left">
                <div class="header-message">
                    Welcome to DivineLook BD!
                </div>
            </div>
            <div class="top-bar-right">

                <div class="dl_socials">
                    <ul class="dl_social_list">
                        <li>
                            <a href="https://www.facebook.com/divinelookbangladesh" class="dl_social-item" target="_blank">
                                <i class="icon fa fa-facebook"></i>
                            </a>
                        </li>
                        <li>
                            <a href="https://twitter.com/DivinelookBD" class="dl_social-item" target="_blank">
                                <i class="icon fa fa-twitter"></i>
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/divinelookbd/" class="dl_social-item" target="_blank">
                                <i class="icon fa fa-instagram"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <ul class="header-user-links">
                    <li>
                        <span class="pipe">|</span>
                        <?php if(!Auth::check()): ?>
                            <a href="<?php echo e(url('/login')); ?>">Login /Register</a>
                        <?php else: ?>
                            <a style="cursor: pointer;" onclick="document.querySelector('#logout').submit()">Log Out</a>
                            <form action="<?php echo e(url('logout')); ?>" id="logout" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>

                        <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="main-header">



                            

            <div class="row">
                <div class="col-lg-3 col-sm-4 col-md-3 col-xs-7 col-ts-12 header-element">
                    <div class="logo">
                        <a href="<?php echo e(url('/')); ?>">
                            <img src="<?php echo e(asset('/frontend/')); ?>/assets/images/logo.png" alt="img">
                        </a>
                    </div>
                </div>
                <div class="col-lg-6 col-sm-8 col-md-5 col-xs-5 col-ts-12">
                    <div class="block-search-block">
                        <form action="<?php echo e(url('product/all')); ?>" class="form-search form-search-width-category">
                            <div class="form-content">

                                <div class="inner">
                                    <input type="text" class="input" name="search" value="<?php echo e(Request::get('search')); ?>" placeholder="Search here">
                                </div>
                                <button class="btn-search custom-btn-color" type="submit">
                                    <span class="icon-search"></span>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-12 col-md-4 col-xs-12 col-ts-12">
                    <div class="header-control">
                        <div class="block-minicart stelina-mini-cart block-header stelina-dropdown">
                            <a href="<?php echo e(url('product/wishlist')); ?>" class="shopcart-icon love-icon" data-stelina="stelina-dropdown">
                                Wishlist
                                <span class="count">
									<?php if(Auth::check()): ?>
                                        <?php echo e(Auth::user()->wishlists->count()); ?>

                                    <?php else: ?>
                                        0
                                    <?php endif; ?>
								</span>
                            </a>
                            <div class="shopcart-description stelina-submenu">
                                <div class="content-wrap">
                                    <?php if(Auth::check()): ?>
                                        <h3 class="title">Wishlist</h3>
                                        <ul class="minicart-items">
                                            <?php $__currentLoopData = Auth::user()->wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wishlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $wishlistProduct = $wishlist->product;
                                                    if($wishlistProduct == null) continue;
                                                ?>
                                                <li class="product-cart mini_cart_item">
                                                    <a href="#" class="product-media">
                                                        <img src="<?php echo e(asset('/product/'.$wishlistProduct->image)); ?>" alt="img">
                                                    </a>
                                                    <div class="product-details">

                                                        <div class="product-remove">
                                                            <a
                                                                href="<?php echo e(url('product/wishlist/remove/' . $wishlistProduct->slug)); ?>"
                                                            ><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                        </div>
                                                        <h5 class="product-name">
                                                            <a href="#"><?php echo e($wishlistProduct->name ?? ''); ?></a>
                                                        </h5>

                                                        <div class="variations text-capitalize">
                                                            <span class="attribute_size">
                                                                <a href="#"><?php echo e($wishlistProduct->brand->name ?? ''); ?></a>
                                                            </span>
                                                        </div>
                                                        <span class="product-price">
                                                            <span>BDT <?php echo e($wishlistProduct->price ?? ''); ?></span>
                                                        </span>
                                                    </div>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>

                                        <br>
                                        <div class="actions">
                                            <a class="button button-viewcart wishlist-login" href="<?php echo e(url('product/wishlist')); ?>">
                                                <span>Go To Wishlist</span>
                                            </a>
                                        </div>

                                    <?php else: ?>
                                        <h3 class="title">Wishlist</h3>
                                        <div class="subtotal">
                                            <span class="total-title">Please login to see your wishlist</span>
                                        </div>
                                        <div class="actions">
                                            <a class="button button-viewcart wishlist-login" href="<?php echo e(url('/login')); ?>">
                                                <span>Login</span>
                                            </a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="block-minicart stelina-mini-cart block-header stelina-dropdown">


                                
                            <style>
                                .add_to_cart_animation {
                                    
                                    position: absolute !important;
                                    top: -58%;
                                    right: -16%;
                                    background: white;
                                    z-index: 9999;
                                    /* width: 9%; */
                                    border-radius: 50%;
                                    <?php if(Session::has('show_cart_animation') && Session::get('show_cart_animation') == true): ?>
                                        display: block;
                                    <?php else: ?>
                                        display: none;
                                    <?php endif; ?>

                                }
                            </style>
                            <img src="<?php echo e(asset('order/add_to_cart.gif')); ?>" class="add_to_cart_animation" alt="">

                            


                            <a href="javascript:void(0);" class="shopcart-icon" data-stelina="stelina-dropdown">
                                Cart
                                <span class="count">
                                    <?php echo e(count($productCount)); ?>

                                </span>
                            </a>
                            <div class="shopcart-description stelina-submenu">
                                <div class="content-wrap">
                                    <h3 class="title">Shopping Cart</h3>
                                    <ul class="minicart-items">
                                        <?php $__currentLoopData = $productCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="product-cart mini_cart_item">
                                                <?php if($cart->product): ?>
                                                <a href="#" class="product-media">
                                                    <img src="<?php echo e(asset('/product/'.$cart->product->image)); ?>" alt="img">
                                                </a>
                                                <?php endif; ?>
                                                <div class="product-details">
                                                    <h5 class="product-name">
                                                        <a href="#"><?php echo e($cart->product->name ?? ''); ?></a>
                                                        <div class="product-remove">
                                                            <a href="<?php echo e(url('/cart/product/delete/'.$cart->id)); ?>"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                        </div>
                                                    </h5>
                                                    <div class="variations">
                                                        <span class="attribute_color">
                                                            <a href="#">Black</a>
                                                        </span>
                                                        <span class="attribute_size">
                                                            <a href="#">300ml</a>
                                                        </span>
                                                    </div>
                                                    <span class="product-price">
                                                        <span>BDT <?php echo e($cart->price ?? ''); ?></span>
                                                    </span>
                                                    <span class="product-quantity">
                                                        (<?php echo e($cart->qty ?? ''); ?>)
                                                    </span>
                                                </div>
                                            </li>
                                            <?php
                                                $subtotal = \App\Models\Cart::where('user_id', auth()->check() ? auth()->user()->id : '')
                                                            ->orWhere('ip_address', request()->ip())->sum('total_price');

                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                    <div class="subtotal">
                                        <span class="total-title">Subtotal: </span>
                                        <span class="total-price">
                                            <span class="Price-amount">
                                                BDT <?php echo e($subtotal ?? '00'); ?>

                                            </span>
                                        </span>
                                    </div>
                                    <div class="actions">
                                        <a class="button button-viewcart custom-btn-color" href="<?php echo e(url('/shopping/cart')); ?>">
                                            <span>View Bag</span>
                                        </a>
                                        <a href="<?php echo e(url('/shipping')); ?>" class="button button-checkout custom-btn-color">
                                            <span>Checkout</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="block-account block-header stelina-dropdown">
                            <a href="javascript:void(0);" data-stelina="stelina-dropdown">
                                <span class="flaticon-user"></span>
                            </a>
                            <div class="header-account stelina-submenu">
                                <div class="header-user-form-tabs">
                                    <ul class="tab-link">
                                        <li class="active">
                                            <?php if(!Auth::check()): ?>
                                                <a data-toggle="tab" aria-expanded="true" href="#header-tab-login">Login</a>
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('users/' . Auth::user()->avatar)); ?>" alt="<?php echo e(Auth::user()->name); ?>" class="img-fluid" style="padding-bottom: 10px;">
                                                <a data-toggle="tab" aria-expanded="true" href="#header-tab-login"><?php echo e(Auth::user()->name); ?></a><br>
                                                <a data-toggle="tab" aria-expanded="true" href="#header-tab-login" style="text-transform: lowercase;"><?php echo e(Auth::user()->email); ?></a>
                                            <?php endif; ?>
                                        </li>

                                    </ul>
                                    <div class="tab-container">
                                        <div id="header-tab-login" class="tab-panel active">
                                            <?php if(!Auth::check()): ?>

                                                <form method="POST" action="<?php echo e(url('/login')); ?>" class="login form-login">
                                                    <?php echo csrf_field(); ?>

                                                    <p class="form-row form-row-wide">
                                                        <input type="email" type="email" name="email"
                                                            required placeholder="Email" class="input-text">

                                                        <?php if($errors->has('email')): ?>
                                                            <p class="text-danger" style="font-size: 14px;"><?php echo e($errors->first('email')); ?></p>
                                                        <?php endif; ?>
                                                    </p>
                                                    <p class="form-row form-row-wide">
                                                        <input type="password" name="password" class="input-text" placeholder="Password" required>

                                                        <?php if($errors->has('password')): ?>
                                                            <p class="text-danger" style="font-size: 14px;"><?php echo e($errors->first('password')); ?></p>
                                                        <?php endif; ?>
                                                    </p>
                                                    <p class="form-row">
                                                        <label class="form-checkbox">
                                                            <input type="checkbox" class="input-checkbox">
                                                            <span>
                                                                        Remember me
                                                                    </span>
                                                        </label>
                                                        <input type="submit" class="button custom-btn-color" value="Login">
                                                    </p>
                                                    <p class="lost_password">
                                                        <a href="<?php echo e(url('password/reset')); ?>">Lost your password?</a>
                                                    </p>
                                                    <p class="lost_password">
                                                        <a href="<?php echo e(url('register')); ?>" class="">Register here</a>
                                                    </p>
                                                </form>

                                            <?php else: ?>
                                                <div class="actions logged_in_box">
                                                    <a class="button button-viewcart" href="<?php echo e(url('profile')); ?>">
                                                        <span>Account</span>
                                                    </a>
                                                    <a  onclick="document.querySelector('#logout').submit()" style="cursor: pointer;" class="button button-checkout">
                                                        <span>Logout</span>
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div id="header-tab-rigister" class="tab-panel">
                                            <form method="post" class="register form-register">
                                                <p class="form-row form-row-wide">
                                                    <input type="email" placeholder="Email" class="input-text">
                                                </p>
                                                <p class="form-row form-row-wide">
                                                    <input type="password" class="input-text" placeholder="Password">
                                                </p>
                                                <p class="form-row">
                                                    <input type="submit" class="button" value="Register">
                                                </p>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a class="menu-bar mobile-navigation menu-toggle" href="#">
                            <span></span>
                            <span></span>
                            <span></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="header-nav-container rows-space-20">
        <div class="container">
            <div class="header-nav-wapper main-menu-wapper">
                <div class="vertical-wapper block-nav-categori custom-btn-color">
                    <div class="block-title">
							<span class="icon-bar">
								<span></span>
								<span></span>
								<span></span>
							</span>
                        <span class="text">All Categories</span>
                    </div>
                    <div class="block-content verticalmenu-content">
                        <ul class="stelina-nav-vertical vertical-menu stelina-clone-mobile-menu">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="menu-item">
                                <a
                                    onclick="document.querySelector('#search' + <?php echo e($category->id); ?> ).submit()"
                                    class="stelina-menu-item-title" title="<?php echo e($category->name ?? '#'); ?>"
                                    style="cursor: pointer;"
                                >
                                    <?php echo e($category->name ?? '#'); ?>

                                </a>
                                <form action="<?php echo e(url('product/all')); ?>" id="search<?php echo e($category->id); ?>" class="d-none">
                                    <input type="hidden" name="cat_ids[]" value="<?php echo e($category->id); ?>">
                                </form>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>

                    </div>
                </div>
                <div class="header-nav">
                    <div class="container-wapper">
                        <ul class="stelina-clone-mobile-menu stelina-nav main-menu " id="menu-main-menu">
                            <li class="menu-item">
                                <a href="<?php echo e(url('/')); ?>" class="stelina-menu-item-title" title="Home">Home</a>
                            </li>
                            <li class="menu-item">
                                <a href="<?php echo e(url('product/all')); ?>" class="stelina-menu-item-title" title="Shop">Shop</a>
                            </li>
                            <li class="menu-item">
                                <a href="<?php echo e(url('/contact')); ?>" class="stelina-menu-item-title" title="About">Contact</a>
                            </li>
                            <li class="menu-item">
                                <a href="<?php echo e(url('/about')); ?>" class="stelina-menu-item-title" title="About">About</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>


<div class="header-device-mobile">
    <div class="wapper">
        <div class="item mobile-logo">
            <div class="logo">
                <a href="<?php echo e(url('/')); ?>">
                    <img src="<?php echo e(asset('/frontend/')); ?>/assets/images/logo.png" alt="img">
                </a>
            </div>
        </div>
        <div class="item item mobile-search-box has-sub">
            <a href="#">
                <span class="icon">
                    <i class="fa fa-search" aria-hidden="true"></i>
                </span>
            </a>
            <div class="block-sub">
                <a href="#" class="close">
                    <i class="fa fa-times" aria-hidden="true"></i>
                </a>
                <div class="header-searchform-box">
                    <form class="header-searchform">
                        <div class="searchform-wrap">
                            <input type="text" class="search-input" placeholder="Enter keywords to search...">
                            <input type="submit" class="submit button" value="Search">
                        </div>
                    </form>
                </div>
            </div>
        </div>



        
        <style>         


            .add_to_cart_animation_mobile {
                
                position: absolute !important;
                top: 0%;
                background: white;
                z-index: 9999;
                <?php if(Session::has('show_cart_animation') && Session::get('show_cart_animation') == true): ?>
                    display: block;
                <?php else: ?>
                    display: none;
                <?php endif; ?>
                
            }

            /* Extra small devices (phones, 450px and down) */
            @media    only screen and (max-width: 359px) {                             
                .add_to_cart_animation_mobile {
                    width: 82%;
                    right: 3%;
                }
            }

            /*360px and up*/
            @media    only screen and (min-width: 360px) {                             
                .add_to_cart_animation_mobile {
                    width: 58%;
                    right: 20%;
                }
            }

            /*450px and up*/
            @media    only screen and (min-width: 450px) {                             
                .add_to_cart_animation_mobile {
                    width: 50%;
                    right: 25%;
                }
            }

            /* Small devices (portrait tablets and large phones, 600px and up) */
            @media    only screen and (min-width: 600px) {                
                .add_to_cart_animation_mobile {
                    width: 37%;
                    right: 32%;
                }
            }

            /* Medium devices (landscape tablets, 768px and up) */
            @media    only screen and (min-width: 768px) {                
                .add_to_cart_animation_mobile {
                    width: 37%;
                    right: 32%;
                }
                
            }

            /* Large devices (laptops/desktops, 992px and up) */
            @media    only screen and (min-width: 992px) {

            }

            /* Extra large devices (large laptops and desktops, 1200px and up) */
            @media    only screen and (min-width: 1200px) {
            }


            .icon2{
                position: relative;
            }
            .count-icon2{
                background-color: #1D043E;
                    width: 20px;
                    height: 20px;
                    text-align: center;
                    line-height: 20px;
                    border-radius: 50%;
                    color: #ffffff;
                    font-weight: 600;
                    display: inline-block;
                    position: absolute;
                    top: 0;
                    right: -10px;
                    font-size: 12px;
            }
            .add_to_cart_animation_mobile_top{
                width: 82%;
                left: 15%;
                top: 21%;
            }

        </style>


        
        <div class="item mobile-settings-box" style="position: relative;">

            <img src="<?php echo e(asset('order/add_to_cart.gif')); ?>" class="add_to_cart_animation_mobile add_to_cart_animation_mobile_top" alt="">
            <a href="<?php echo e(url('/shopping/cart')); ?>">
                    <span class="icon icon2">
                        <i class="fa fa-shopping-basket" aria-hidden="true"></i>
                        <span class="count-icon count-icon2">
                            <?php echo e(count($productCount)); ?>

                        </span>
                    </span>
                
            </a>
        </div>
        <div class="item menu-bar">
            <a class=" mobile-navigation  menu-toggle" href="#">
                <span></span>
                <span></span>
                <span></span>
            </a>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/frontend/includes/header.blade.php ENDPATH**/ ?>