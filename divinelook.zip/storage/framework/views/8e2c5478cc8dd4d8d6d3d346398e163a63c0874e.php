<!DOCTYPE html>
<html lang="en">
<head>
    <title>DivineLook - <?php echo $__env->yieldContent('title'); ?></title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo $__env->make('frontend.includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('style'); ?>
</head>
<body class="home">



<!-- ======================= Header ======================== -->
<?php echo $__env->make('frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ======================= Customer Features ======================== -->
<?php echo $__env->yieldContent('content'); ?>
<!-- ======================= Customer Features ======================== -->

<!-- ======================= Footer ======================== -->
<?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ======================= Popup ======================== -->
<?php echo $__env->make('frontend.includes.popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- ======================= Mobile header ======================== -->
<?php echo $__env->make('frontend.includes.mobile_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<a href="#" class="backtotop">
    <i class="fa fa-angle-double-up"></i>
</a>
<?php echo $__env->make('frontend.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent('script'); ?>
</body>


</html>
<?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/frontend/master.blade.php ENDPATH**/ ?>