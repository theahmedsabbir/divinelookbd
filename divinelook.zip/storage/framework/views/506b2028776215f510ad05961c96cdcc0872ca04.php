
<div class="sidebar col-lg-3 col-md-3 col-sm-12 col-xs-12">
    <div class="wrapper-sidebar shop-sidebar">
        <div class="widget woof_Widget">
            <div class="widget widget-categories">
                <h3 class="widgettitle">Categories</h3>
                <ul class="list-categories">
                	<?php $__currentLoopData = $products->groupBy('cat_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_id => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<?php
                		$category = App\Models\Category::find($cat_id);
                		if($category == null){
                			continue;
                		}
                	?>

                    <li>
                        <input type="checkbox" id="<?php echo e('category'.$category->id); ?>" name="cat_ids[]" value="<?php echo e($category->id); ?>"

                        	<?php if(Request::get('cat_ids') && in_array($category->id, Request::get('cat_ids'))): ?>
                        		checked
                        	<?php endif; ?>

                        >
                        <label for="<?php echo e('category'.$category->id); ?>" class="label-text">
                            <?php echo e($category->name); ?>

                        </label>
                    </li>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="widget widget_filter_price">
                <h4 class="widgettitle">
                    Price
                </h4>

                <?php
                	$max_price = App\Models\Product::max('price') ?? 0;
                	// $max_price = $products->max('price') ?? 0;
                	// $min_price = $products->min('price') ?? 0;
                ?>

                <div class="price-slider-wrapper">
                    <div data-label-reasult="Range:"
                    	data-min="0" data-max="<?php echo e($max_price); ?>" data-unit="৳"
                        class="slider-range-price "
                        data-value-min="<?php echo e(Request::get('min_price') ?? 0); ?>"
                        data-value-max="<?php echo e(Request::get('max_price') ?? $max_price); ?>"
                    >
                    </div>
                    <div class="price-slider-amount">
                    	<input type="number"
                    		name="min_price" value="<?php echo e(Request::get('min_price') ?? 0); ?>"
                    		oninput="update_slider()"
                    		min="0" max="<?php echo e($max_price); ?>"
                    		class="from" id="from" placeholder="min"
                		>
                    	<input type="number"
                    		name="max_price" value="<?php echo e(Request::get('max_price') ?? $max_price); ?>"
                    		oninput="update_slider()"
                    		min="0" max="<?php echo e($max_price); ?>"
                    		class="from" id="to" placeholder="max"
                		>

                    </div>
                </div>
            </div>
            <div class="widget widget-categories">
                <h3 class="widgettitle">Brands</h3>
                <ul class="list-categories">
                	<?php $__currentLoopData = $products->groupBy('brand_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand_id => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<?php
                		$brand = App\Models\Brand::find($brand_id);
                		if($brand == null){
                			continue;
                		}
                	?>

                    <li>
                        <input type="checkbox" id="<?php echo e('brand'.$brand->id); ?>" name="brand_ids[]" value="<?php echo e($brand->id); ?>"

                        	<?php if(Request::get('brand_ids') && in_array($brand->id, Request::get('brand_ids'))): ?>
                        		checked
                        	<?php endif; ?>

                        >
                        <label for="<?php echo e('brand'.$brand->id); ?>" class="label-text">
                            <?php echo e($brand->name); ?>

                        </label>
                    </li>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="widget widget-categories">
                <h3 class="widgettitle">Colors</h3>
                <ul class="list-categories">
                	<?php
                		// collecting unique color ids first
                		$color_ids = [];
                		foreach ($products as $key => $product) {
                			if($product->colors == null) continue;
                			foreach (json_decode($product->colors) as $color_id) {

                				// jodi array te na thake tahole in koro
                				if(!in_array($color_id, $color_ids)){
                					array_push($color_ids, $color_id);
                				}
                			}
                		}
                	?>


                	
                	<?php $__currentLoopData = $color_ids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color_id2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<?php
                		$color = App\Models\Color::find($color_id2);
                		if($color == null) continue;
                	?>
                    <li>
                        <input type="checkbox" id="<?php echo e('color'.$color->id); ?>" name="color_ids[]" value="<?php echo e($color->id); ?>"


                        	<?php if(Request::get('color_ids') && in_array($color->id, Request::get('color_ids'))): ?>
                        		checked
                        	<?php endif; ?>

                        >
                        <label for="<?php echo e('color'.$color->id); ?>" class="label-text">
                            <?php echo e($color->name); ?>

                        </label>
                    </li>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <div class="widget widget-categories">
                <h3 class="widgettitle">Types</h3>
                <ul class="list-categories">
                	
                	<?php
                		$types = []; //take a array for keeping memory
                	?>
                	<?php $__currentLoopData = $products->pluck('type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                	<?php
                		// jodi array te thake taile contine, else array te rakho and show koro
                		if (!in_array($type, $types) && $type != null) {
                			array_push($types, $type);
                		}else{
                			continue;
                		}
                	?>

                    <li>
                        <input type="checkbox" id="<?php echo e('type'.$type); ?>" name="types[]" value="<?php echo e($type); ?>"

                        	<?php if(Request::get('types') && in_array($type, Request::get('types'))): ?>
                        		checked
                        	<?php endif; ?>

                        >
                        <label for="<?php echo e('type'.$type); ?>" class="label-text">
                            <?php echo e($type); ?>

                        </label>
                    </li>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <?php if(Request::filled('search')): ?>
        	<input type="hidden" name="search" value="<?php echo e(Request::get('search')); ?>">
        <?php endif; ?>
        <div class="widget">
            <button type="submit" class="button submit-newsletter custom-btn-color">Filter</button>
            <button type="button"
            	class="button"style="background-color: #EE1C47"
            	onclick="location.href='<?php echo e(url('product/all')); ?>'"
        	>Clear</button>
        </div>
        <div class="widget newsletter-widget">
            <div class="newsletter-form-wrap ">
                <h3 class="title">Subscribe to Our Newsletter</h3>
                <div class="subtitle">
                    More special Deals, Events & Promotions
                </div>
                <input type="email" class="email" placeholder="Your email letter">
                <button type="button" class="button submit-newsletter custom-btn-color">Subscribe</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\lp\divinelook\resources\views/frontend/product/includes/filter.blade.php ENDPATH**/ ?>